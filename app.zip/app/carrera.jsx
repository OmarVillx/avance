import { useRouter } from "expo-router";
import { SafeAreaView, Text, TextInput, TouchableOpacity } from "react-native";
import styles from "./csscarrera";

export default function Carrera() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Carrera y ciclo</Text>

      <TextInput
        placeholder="Ej: Ingeniería de Sistemas"
        placeholderTextColor="#888"
        style={styles.input}
      />

      <TextInput
        placeholder="Ej: 4to ciclo"
        placeholderTextColor="#888"
        style={styles.input}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push("/usuario")}
      >
        <Text style={styles.buttonText}>Continuar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
