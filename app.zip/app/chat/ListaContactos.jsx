import { Ionicons } from "@expo/vector-icons";
import { Image, ScrollView, Text, TouchableOpacity, View } from "react-native";
import styles from "./cssListaContactos";

export default function ListaContactos({
  contactos,
  chatSeleccionado,
  onSelectChat,
}) {
  const amigos = contactos.filter((item) => item.tipo === "amigo");
  const grupos = contactos.filter((item) => item.tipo === "grupo");

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.sectionHeader}>
        <Ionicons name="people-outline" size={18} color="#E60023" />
        <Text style={styles.sectionTitle}>AMIGOS</Text>
      </View>

      {amigos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.contactItem,
            chatSeleccionado?.id === item.id && styles.contactActive,
          ]}
          onPress={() => onSelectChat(item)}
        >
          <View style={styles.avatarContainer}>
            <Image source={{ uri: item.avatar }} style={styles.avatar} />
            <View
              style={[
                styles.statusDot,
                item.estado === "Ausente" && styles.statusAway,
              ]}
            />
          </View>
          <View style={styles.contactInfo}>
            <Text style={styles.contactName}>{item.nombre}</Text>
            <Text style={styles.contactStatus}>• {item.estado}</Text>
          </View>
        </TouchableOpacity>
      ))}

      <View style={[styles.sectionHeader, styles.marginTop]}>
        <Ionicons name="people-outline" size={18} color="#E60023" />
        <Text style={styles.sectionTitle}>SERVIDORES UTP+</Text>
      </View>

      {grupos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.contactItem,
            chatSeleccionado?.id === item.id && styles.contactActive,
          ]}
          onPress={() => onSelectChat(item)}
        >
          <Image source={{ uri: item.avatar }} style={styles.avatar} />
          <View style={styles.contactInfo}>
            <Text style={styles.contactName}>{item.nombre}</Text>
            <Text style={styles.contactStatus}>Servidor UTP+</Text>
          </View>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{item.mensajesNoLeidos || 0}</Text>
          </View>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}
