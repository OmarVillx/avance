import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import {
  Image,
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import styles from "./csschat";

export default function Chat() {
  const contactos = [
    {
      id: 1,
      nombre: "TzNakroth",
      estado: "En línea",
      tipo: "amigo",
      avatar: "https://i.pravatar.cc/150?img=12",
    },
    {
      id: 2,
      nombre: "CodeMaster",
      estado: "En línea",
      tipo: "amigo",
      avatar: "https://i.pravatar.cc/150?img=13",
    },
    {
      id: 3,
      nombre: "MichiUTP",
      estado: "En línea",
      tipo: "amigo",
      avatar: "https://i.pravatar.cc/150?img=5",
    },
    {
      id: 4,
      nombre: "SofiDev",
      estado: "Ausente",
      tipo: "amigo",
      avatar: "https://i.pravatar.cc/150?img=47",
    },
    {
      id: 5,
      nombre: "General UTP+",
      estado: "3",
      tipo: "grupo",
      avatar: "https://i.pravatar.cc/150?img=20",
    },
    {
      id: 6,
      nombre: "Ing. Sistemas",
      estado: "12",
      tipo: "grupo",
      avatar: "https://i.pravatar.cc/150?img=22",
    },
    {
      id: 7,
      nombre: "Gamers UTP",
      estado: "8",
      tipo: "grupo",
      avatar: "https://i.pravatar.cc/150?img=30",
    },
    {
      id: 8,
      nombre: "Memes UTP",
      estado: "15",
      tipo: "grupo",
      avatar: "https://i.pravatar.cc/150?img=31",
    },
  ];

  const mensajesDemo = [
    { id: 1, texto: "Holaa 👋", hora: "8:20 a. m.", mio: false },
    { id: 2, texto: "¿Cómo estás?", hora: "8:20 a. m.", mio: false },
    { id: 3, texto: "Holaa SofiDev 👋", hora: "8:21 a. m.", mio: true },
    {
      id: 4,
      texto: "Todo bien, gracias por preguntar, ¿y tú?",
      hora: "8:21 a. m.",
      mio: true,
    },
    {
      id: 5,
      texto: "Bien bien, aquí terminando un proyecto jaja 😅",
      hora: "8:22 a. m.",
      mio: false,
    },
    { id: 6, texto: "Qué proo ¿de qué trata?", hora: "8:23 a. m.", mio: true },
    {
      id: 7,
      texto: "Es de una app para la uni 😎 Ya casi la termino",
      hora: "8:24 a. m.",
      mio: false,
    },
    {
      id: 8,
      texto: "Nicee 🔥 cuando la termines me muestras",
      hora: "8:24 a. m.",
      mio: true,
    },
  ];

  const [chatSeleccionado, setChatSeleccionado] = useState(contactos[3]);
  const amigos = contactos.filter((item) => item.tipo === "amigo");
  const grupos = contactos.filter((item) => item.tipo === "grupo");

  return (
    <SafeAreaView style={styles.container}>
      {/* HEADER */}
      <View style={styles.header}>
        <TouchableOpacity>
          <Text style={styles.logo}>
            UTP+ <Text style={styles.logoBlanco}>Movil</Text>
          </Text>
        </TouchableOpacity>

        <View style={styles.headerIcons}>
          <Ionicons name="search-outline" size={28} color="white" />
          <Ionicons name="add-circle-outline" size={29} color="white" />
        </View>
      </View>

      <View style={styles.body}>
        {/* IZQUIERDA */}
        <View style={styles.sidebar}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <Text style={styles.sectionTitle}>AMIGOS</Text>

            {amigos.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={[
                  styles.contactItem,
                  chatSeleccionado.id === item.id && styles.contactActive,
                ]}
                onPress={() => setChatSeleccionado(item)}
              >
                <View>
                  <Image source={{ uri: item.avatar }} style={styles.avatar} />
                  <View
                    style={[
                      styles.statusDot,
                      item.estado === "Ausente" && styles.statusAway,
                    ]}
                  />
                </View>

                <View style={styles.contactInfo}>
                  <Text style={styles.contactName}>{item.nombre}</Text>
                  <Text style={styles.contactStatus}>• {item.estado}</Text>
                </View>
              </TouchableOpacity>
            ))}

            <Text style={[styles.sectionTitle, styles.groupTitle]}>GRUPOS</Text>

            {grupos.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={[
                  styles.contactItem,
                  chatSeleccionado.id === item.id && styles.contactActive,
                ]}
                onPress={() => setChatSeleccionado(item)}
              >
                <Image source={{ uri: item.avatar }} style={styles.avatar} />

                <View style={styles.contactInfo}>
                  <Text style={styles.contactName}>{item.nombre}</Text>
                  <Text style={styles.contactStatus}>Servidor UTP+</Text>
                </View>

                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{item.estado}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* DERECHA */}
        <View style={styles.chatPanel}>
          <View style={styles.chatHeader}>
            <Ionicons name="chevron-back-outline" size={30} color="white" />

            <Image
              source={{ uri: chatSeleccionado.avatar }}
              style={styles.chatAvatar}
            />

            <View style={styles.chatHeaderInfo}>
              <Text style={styles.chatName}>{chatSeleccionado.nombre}</Text>
              <Text style={styles.chatStatus}>
                {chatSeleccionado.tipo === "grupo"
                  ? "Chat grupal"
                  : chatSeleccionado.estado}
              </Text>
            </View>

            <Ionicons
              name="information-circle-outline"
              size={30}
              color="white"
            />
          </View>

          <ScrollView
            style={styles.messages}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.dayBox}>
              <Text style={styles.dayText}>Hoy</Text>
            </View>

            {mensajesDemo.map((msg) => (
              <View
                key={msg.id}
                style={[
                  styles.messageRow,
                  msg.mio ? styles.messageRight : styles.messageLeft,
                ]}
              >
                {!msg.mio && (
                  <Image
                    source={{ uri: chatSeleccionado.avatar }}
                    style={styles.messageAvatar}
                  />
                )}

                <View
                  style={[
                    styles.bubble,
                    msg.mio ? styles.myBubble : styles.otherBubble,
                  ]}
                >
                  <Text style={styles.messageText}>{msg.texto}</Text>

                  <Text style={styles.messageTime}>
                    {msg.hora} {msg.mio ? "✓✓" : ""}
                  </Text>
                </View>
              </View>
            ))}
          </ScrollView>

          <View style={styles.inputArea}>
            <TouchableOpacity style={styles.circleButton}>
              <Ionicons name="add-outline" size={26} color="#E60023" />
            </TouchableOpacity>

            <TextInput
              style={styles.input}
              placeholder="Escribe un mensaje..."
              placeholderTextColor="#8A8A8A"
            />

            <Ionicons name="happy-outline" size={26} color="#B8B8B8" />
            <Ionicons name="mic-outline" size={27} color="#E60023" />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}
