import { useRouter } from "expo-router";
import { SafeAreaView, Text, TouchableOpacity, View } from "react-native";
import styles from "./cssintereses";

export default function Intereses() {
  const router = useRouter();
  const intereses = [
    "🎮 Videojuegos",
    "💻 Tecnología",
    "😂 Memes",
    "🎵 Música",
    "🎬 Entretenimiento",
    "🏋️ Gym",
  ];

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Selecciona tus intereses</Text>
      <View style={styles.grid}>
        {intereses.map((item, index) => (
          <TouchableOpacity key={index} style={styles.card}>
            <Text style={styles.cardText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <TouchableOpacity
        style={styles.nextButton}
        onPress={() => router.push("/carrera")}
      >
        <Text style={styles.nextText}>Continuar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
