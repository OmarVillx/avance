import { useRouter } from "expo-router";
import { SafeAreaView, ScrollView, Text, TouchableOpacity, View } from "react-native";
import styles from "./cssintereses";

export default function Intereses() {
  const router = useRouter();
  const intereses = [
    "🎮 Videojuegos",
    "💻 Tecnología",
    "😂 Memes",
    "🎵 Música",
    "🎬 Entretenimiento",
    "🏋️ Gym",
    "📚 Estudio",
    "🎨 Arte",
    "📷 Fotografía",
    "🍕 Comida",
    "✈️ Viajes",
    "🐶 Mascotas",
    "⚽ Deportes",
    "📺 Series",
    "🎧 Podcasts",
    "📖 Lectura",
    "💼 Emprendimiento",
    "🤖 IA / Programación",
    "🎲 Juegos de Mesa",
    "🌱 Vida Saludable",
  ];

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Selecciona tus intereses</Text>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.grid}>
          {intereses.map((item, index) => (
            <TouchableOpacity key={index} style={styles.card}>
              <Text style={styles.cardText}>{item}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <TouchableOpacity
        style={styles.nextButton}
        onPress={() => router.push("/carrera")}
      >
        <Text style={styles.nextText}>Continuar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
