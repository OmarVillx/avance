import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  Alert,
  Modal,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { WebView } from "react-native-webview";
import styles, { ColorLogin } from "./csslogin";

export default function Login() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [showWebView, setShowWebView] = useState(false);

  // URL del SSO de UTP
  const SSO_URL =
    "https://sso.utp.edu.pe/auth/realms/Xpedition/protocol/openid-connect/auth" +
    "?client_id=pao-web" +
    "&redirect_uri=" +
    encodeURIComponent("https://class.utp.edu.pe/student/courses") +
    "&response_type=code" +
    "&scope=openid" +
    "&state=" +
    Date.now();

  const verificarAutenticacionUTP = async (authUrl) => {
    try {
      setIsLoading(true);
      console.log("Autenticación UTP verificada:", authUrl);
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setIsLoading(false);
      router.push("/genero");
    } catch (error) {
      console.error("Error en verificación:", error);
      setIsLoading(false);
      Alert.alert(
        "Error",
        "No se pudo verificar la autenticación. Inténtalo de nuevo.",
      );
    }
  };

  const handleLoginUTP = () => {
    setShowWebView(true);
  };

  const handleNavigationStateChange = (navState) => {
    const { url } = navState;
    console.log("Navegando a:", url);

    // Si la URL cambia a class.utp o contiene el código de éxito, lo capturamos
    if (url.includes("class.utp.edu.pe") || url.includes("code=")) {
      // Evitamos que siga cargando la página web real
      setShowWebView(false);
      verificarAutenticacionUTP(url);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.trianguloDerecha} />
      <View style={styles.trianguloIzquierda} />

      <View style={styles.content}>
        <View style={styles.logoRow}>
          <View style={[styles.logoBox, styles.logoRed]}>
            <Text style={styles.logoText}>U</Text>
          </View>
          <View style={[styles.logoBox, styles.logoDark]}>
            <Text style={styles.logoText}>T</Text>
          </View>
          <View style={[styles.logoBox, styles.logoRed]}>
            <Text style={styles.logoText}>P</Text>
          </View>
          <Text style={styles.plus}>+</Text>
          <Text style={styles.movil}>Movil</Text>
        </View>

        <Text style={styles.title}>Bienvenido a UTP+Movil</Text>
        <Text style={styles.subtitle}>
          Conéctate con tu comunidad universitaria{"\n"}y vive la experiencia
          UTP.
        </Text>

        <View style={styles.spacing} />

        <TouchableOpacity
          style={[styles.utpButton, isLoading && styles.buttonDisabled]}
          onPress={handleLoginUTP}
          disabled={isLoading}
        >
          {isLoading ? (
            <Text style={styles.utpText}>Conectando...</Text>
          ) : (
            <>
              <Ionicons name="school" size={24} color={ColorLogin.blanco} />
              <Text style={styles.utpText}>Iniciar Sesión con UTP+Class</Text>
            </>
          )}
        </TouchableOpacity>

        <Text style={styles.infoText}>
          Serás redirigido al portal de la UTP para verificar tu identidad
        </Text>
      </View>

      {/* Modal con el WebView para el SSO */}
      <Modal visible={showWebView} animationType="slide">
        <SafeAreaView style={{ flex: 1, backgroundColor: "#000" }}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              padding: 15,
              backgroundColor: "#111",
            }}
          >
            <Text style={{ color: "white", fontSize: 16, fontWeight: "bold" }}>
              Autenticación UTP
            </Text>
            <TouchableOpacity onPress={() => setShowWebView(false)}>
              <Text style={{ color: "#E60023", fontSize: 16, fontWeight: "bold" }}>
                Cancelar
              </Text>
            </TouchableOpacity>
          </View>
          <WebView
            source={{ uri: SSO_URL }}
            onNavigationStateChange={handleNavigationStateChange}
            startInLoadingState={true}
            incognito={true} /* Recomendado para que no guarde caché vieja del SSO */
          />
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}
