import { Ionicons } from "@expo/vector-icons";
import { Image, Text, TouchableOpacity, View } from "react-native";
import styles from "./cssGrupo";

export default function Grupo({ data, onPress }) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.avatarContainer}>
        <Image source={{ uri: data.avatar }} style={styles.avatar} />
        <View style={[styles.iconoBadge, styles.bgVerde]}>
          <Ionicons name="people" size={14} color="white" />
        </View>
      </View>

      <View style={styles.textoContainer}>
        <Text style={styles.textoPrincipal}>
          <Text style={styles.usuarioNegrita}>{data.grupo} </Text>
          {data.texto}
        </Text>
        <Text style={styles.textoDetalle}>{data.detalle}</Text>
        <Text style={styles.hora}>{data.hora}</Text>
      </View>

      {!data.visto && <View style={styles.puntoVerde} />}
    </TouchableOpacity>
  );
}
