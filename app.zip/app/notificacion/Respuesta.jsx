import { Ionicons } from "@expo/vector-icons";
import { Image, Text, TouchableOpacity, View } from "react-native";
import styles from "./cssRespuesta";

export default function Respuesta({ data, onPress }) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.avatarContainer}>
        <Image source={{ uri: data.avatar }} style={styles.avatar} />
        <View style={[styles.iconoBadge, styles.bgAzul]}>
          <Ionicons name="chatbubble" size={14} color="white" />
        </View>
      </View>

      <View style={styles.textoContainer}>
        <Text style={styles.textoPrincipal}>
          <Text style={styles.usuarioNegrita}>{data.usuario} </Text>
          {data.texto}
        </Text>
        {data.detalle && (
          <Text style={styles.textoDetalle}>"{data.detalle}"</Text>
        )}
        <Text style={styles.hora}>{data.hora}</Text>
      </View>

      {!data.visto && <View style={styles.puntoAzul} />}
    </TouchableOpacity>
  );
}
