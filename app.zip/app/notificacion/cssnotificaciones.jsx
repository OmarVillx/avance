import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#050505",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  logo: {
    color: "#E60023",
    fontSize: 32,
    fontWeight: "900",
  },
  logoBlanco: {
    color: "#FFFFFF",
    fontSize: 22,
    fontWeight: "800",
  },
  marcarLeidas: {
    color: "#8A8A8A",
    fontSize: 14,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#111",
    borderRadius: 12,
    paddingHorizontal: 15,
    marginHorizontal: 20,
    marginBottom: 15,
    height: 45,
  },
  searchInput: {
    flex: 1,
    color: "white",
    fontSize: 14,
    marginLeft: 10,
  },
  filtros: {
    paddingHorizontal: 15,
    marginBottom: 15,
  },
  filtro: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1A1A1A",
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
  },
  filtroActivo: {
    backgroundColor: "#E60023",
  },
  filtroTexto: {
    color: "#8A8A8A",
    fontSize: 13,
    fontWeight: "600",
  },
  filtroTextoActivo: {
    color: "white",
  },
  filtroBadge: {
    marginLeft: 8,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
    minWidth: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  filtroBadgeActivo: {
    backgroundColor: "rgba(255,255,255,0.3)",
  },
  filtroBadgeInactivo: {
    backgroundColor: "#8A8A8A",
  },
  filtroBadgeText: {
    color: "white",
    fontSize: 11,
    fontWeight: "bold",
  },
  emptyState: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
  },
  emptyText: {
    color: "#666",
    fontSize: 16,
    marginTop: 15,
  },
  bottomNav: {
    height: 85,
    backgroundColor: "#050505",
    borderTopWidth: 1,
    borderTopColor: "#1F1F1F",
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    paddingBottom: 15,
  },
  navItem: {
    alignItems: "center",
    justifyContent: "center",
  },
  navText: {
    color: "#8A8A8A",
    fontSize: 11,
    marginTop: 4,
  },
  navTextActive: {
    color: "#E60023",
    fontWeight: "bold",
  },
});

export default styles;
