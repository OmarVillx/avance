import { Ionicons } from "@expo/vector-icons";
import { Text, TouchableOpacity, View } from "react-native";
import styles from "./cssPerfilHeader";

export default function PerfilHeader({ onMenuPress }) {
  return (
    <View style={styles.container}>
      <Text style={styles.logo}>
        UTP+ <Text style={styles.logoBlanco}>Movil</Text>
      </Text>
      <TouchableOpacity onPress={onMenuPress}>
        <Ionicons name="ellipsis-horizontal" size={28} color="white" />
      </TouchableOpacity>
    </View>
  );
}
