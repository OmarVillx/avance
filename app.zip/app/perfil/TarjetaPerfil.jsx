import { Image, Text, View } from "react-native";
import styles from "./cssTarjetaPerfil";

export default function TarjetaPerfil({ usuario }) {
  return (
    <View style={styles.container}>
      <View style={styles.avatarContainer}>
        <Image source={{ uri: usuario.avatar }} style={styles.avatar} />
        <View
          style={[
            styles.statusDot,
            usuario.estado === "Ausente" && styles.statusAway,
          ]}
        />
      </View>

      <Text style={styles.username}>{usuario.username}</Text>
      <Text style={styles.carrera}>
        {usuario.carrera} • {usuario.ciclo}
      </Text>

      <View style={styles.bioContainer}>
        <Text style={styles.comillas}>“</Text>
        <Text style={styles.bio}>{usuario.bio}</Text>
      </View>
    </View>
  );
}
