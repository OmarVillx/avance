import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import styles from "./cssperfil";

// Componentes del perfil
import DatosRegistro from "./DatosRegistro";
import EstadoActual from "./EstadoActual";
import ListaComunidades from "./ListaComunidades";
import ListaPublicaciones from "./ListaPublicaciones";
import MenuDesplegable from "./MenuDesplegable";
import PerfilHeader from "./PerfilHeader";
import TarjetaPerfil from "./TarjetaPerfil";

export default function Perfil() {
  const router = useRouter();
  const [menuVisible, setMenuVisible] = useState(false);

  // Datos simulados (después vendrán de PostgreSQL)
  // ✅ CORRECCIÓN: Eliminados espacios al final de cada texto
  const usuario = {
    username: "@TzNakroth",
    nombreReal: "TzNakroth",
    avatar: "https://i.pravatar.cc/150?img=12",
    carrera: "Ing. Sistemas",
    ciclo: "4to ciclo",
    estado: "En línea",
    bio: "Programando, sobreviviendo parciales y full café ☕",
    genero: "Masculino",
    intereses: [
      "Tecnología",
      "Videojuegos",
      "Programación",
      "Anime",
      "Música",
      "Café",
    ],
  };

  const comunidades = [
    {
      id: 1,
      nombre: "Gamers UTP",
      miembros: "1.2k",
      icono: "https://i.pravatar.cc/150?img=30",
    },
    {
      id: 2,
      nombre: "Ing. Sistemas",
      miembros: "892",
      icono: "https://i.pravatar.cc/150?img=60",
    },
    {
      id: 3,
      nombre: "Memes UTP",
      miembros: "2.5k",
      icono: "https://i.pravatar.cc/150?img=31",
    },
    {
      id: 4,
      nombre: "Anime/Manhwa",
      miembros: "1.1k",
      icono: "https://i.pravatar.cc/150?img=47",
    },
  ];

  const publicaciones = [
    {
      id: 1,
      titulo: "¿Quién entendió Base de Datos? 💀",
      etiqueta: "Discusión",
      likes: 128,
      comentarios: 23,
      hora: "Hace 2 días",
    },
    {
      id: 2,
      titulo: "Nuevo setup para programar 🌙",
      etiqueta: "Imagen",
      likes: 96,
      comentarios: 18,
      hora: "Hace 4 días",
      imagen: "https://i.pravatar.cc/150?img=setup",
    },
    {
      id: 3,
      titulo: "Meme del parcial de Algoritmos 😂",
      etiqueta: "Meme",
      likes: 75,
      comentarios: 12,
      hora: "Hace 1 semana",
      imagen: "https://i.pravatar.cc/150?img=meme",
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      {/* HEADER */}
      <PerfilHeader onMenuPress={() => setMenuVisible(!menuVisible)} />

      {/* MENÚ DESPLEGABLE */}
      {menuVisible && (
        <MenuDesplegable
          visible={menuVisible}
          onClose={() => setMenuVisible(false)}
          onCerrarSesion={() => router.push("/")}
        />
      )}

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* TARJETA DE PERFIL PRINCIPAL */}
        <TarjetaPerfil usuario={usuario} />

        {/* DATOS DEL REGISTRO */}
        <DatosRegistro usuario={usuario} />

        {/* ESTADO ACTUAL */}
        <EstadoActual />

        {/* COMUNIDADES */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>COMUNIDADES</Text>
            <TouchableOpacity>
              <Text style={styles.verTodas}>Ver todas →</Text>
            </TouchableOpacity>
          </View>
          <ListaComunidades comunidades={comunidades} />
        </View>

        {/* PUBLICACIONES */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>MIS PUBLICACIONES</Text>
            <TouchableOpacity>
              <Text style={styles.verTodas}>Ver todas →</Text>
            </TouchableOpacity>
          </View>
          <ListaPublicaciones publicaciones={publicaciones} />
        </View>
      </ScrollView>

      {/* BOTTOM NAV */}
      <View style={styles.bottomNav}>
        <TouchableOpacity
          style={styles.navItem}
          onPress={() => router.push("/inicio")}
        >
          <Ionicons name="home-outline" size={28} color="#8A8A8A" />
          <Text style={styles.navText}>Inicio</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          onPress={() => router.push("/chat/chat")}
        >
          <Ionicons name="chatbubble-outline" size={28} color="#8A8A8A" />
          <Text style={styles.navText}>Chat</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          onPress={() => router.push("/inicio/crearpublicacion")}
        >
          <Ionicons name="add-circle-outline" size={32} color="#8A8A8A" />
          <Text style={styles.navText}>Crear</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          onPress={() => router.push("/notificacion/notificaciones")}
        >
          <Ionicons name="notifications-outline" size={28} color="#8A8A8A" />
          <Text style={styles.navText}>Notificaciones</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navItem}>
          <Ionicons name="person" size={28} color="#E60023" />
          <Text style={[styles.navText, styles.navTextActive]}>Perfil</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
