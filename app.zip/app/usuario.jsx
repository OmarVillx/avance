import { useRouter } from "expo-router";
import { SafeAreaView, Text, TextInput, TouchableOpacity } from "react-native";
import styles from "./cssusuario";

export default function Usuario() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Crea tu nombre de usuario</Text>

      <TextInput
        placeholder="@TzNakroth"
        placeholderTextColor="#888"
        style={styles.input}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push("/inicio")}
      >
        <Text style={styles.buttonText}>Continuar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
